# aicms

**aicms** is a small **AI-powered content layer for Next.js** (React 19+). Site owners edit copy, business info, SEO fields, and restaurant-style menus **through natural language** in a floating chat widget, instead of editing code or a traditional admin panel. The library stores content in **SQLite** (local) or **Turso** (hosted), exposes it to pages via **React context and hooks**, and uses **Anthropic’s Claude** with **tool use** to read and write that data safely through a defined API.

---

## What this application (library) does

1. **Database-backed CMS**  
   Flat key–value content (e.g. `business.phone`, `seo.home.description`), structured **menu items** (with prices in cents), and **testimonials** live in SQL tables. Adapters implement one interface for file-based SQLite and remote Turso.

2. **Next.js integration**  
   Server helpers load content for **Server Components** and **metadata** (titles, descriptions, JSON-LD). Client components wrap the app in `CmsProvider` and use hooks like `useBusiness()`, `useMenu()`, `useContent("hero.title")` so pages stay reactive when content refreshes.

3. **AI agent**  
   The `runAgent` function in `src/ai/agent.ts` sends the conversation plus a **system prompt** (built from current DB snapshot) to Claude. Claude can call **tools**: read/update content keys, list keys, CRUD menu items, and request **revalidation** paths. Your code executes tools against storage and returns plain-text results to the model until it answers with a final message.

4. **HTTP API + widget**  
   `createCmsApiHandler` serves authenticated **POST** chat requests (runs the agent) and can **GET** full site content for refresh. The **CMS widget** is a floating button that opens a panel: sign-in gate + chat UI that talks to that API.

5. **CLI**  
   `npx aicms init` scaffolds wiring into a Next.js app; `npx aicms extract` can pull content from existing project files into the database (see CLI output for details).

6. **Standalone service (SaaS-style)**  
   Run **one HTTP process** for many customers: each customer gets an **API key** you issue, mapped to an **isolated database**. You keep **your** `ANTHROPIC_API_KEY` on the server; customers authenticate with **their** key via `X-API-Key` or `Authorization: Bearer`.

---

## Hosted service (`aicms serve`)

**Local try (no key file yet):**

```bash
export AICMS_DEV=1
npm run build && npx aicms serve
```

Uses API key `dev-local-key` and `./data/dev/aicms.db` (override with `AICMS_DEV_API_KEY` / `AICMS_DB_PATH`).

**Production-style:**

```bash
export ANTHROPIC_API_KEY=sk-ant-...
export AICMS_SERVICE_API_KEY=sk_customer_001
export AICMS_DB_PATH=./data/default/aicms.db
npx aicms serve
```

The `aicms-service` binary is only on your PATH after `npm install -g .` or via `npm exec aicms-service` / `npm run service` from this repo (after `npm run build`).

**Multi-tenant** — JSON map of keys to tenants (`AICMS_SERVICE_KEYS`):

```bash
export AICMS_SERVICE_KEYS='{"sk_acme_xxx":{"tenantId":"acme","dbPath":"./data/acme/aicms.db"},"sk_bob_yyy":{"tenantId":"bob","tursoUrl":"libsql://...","tursoToken":"..."}}'
```

| Variable | Purpose |
|----------|---------|
| `AICMS_DEV` | Set to `1` or `true` to enable a default dev key (`dev-local-key`) and `./data/dev/aicms.db` |
| `AICMS_DEV_API_KEY` | Override the dev default key (only with `AICMS_DEV`) |
| `AICMS_SERVICE_KEYS` | JSON: `apiKey → { tenantId, dbPath? \| tursoUrl? + tursoToken? }` |
| `AICMS_SERVICE_API_KEY` | Single key + optional `AICMS_DB_PATH` / `AICMS_SERVICE_TENANT_ID` |
| `PORT` / `AICMS_SERVICE_PORT` | Port (default `3847`) |
| `AICMS_SERVICE_HOST` | Bind (default `0.0.0.0`) |
| `AICMS_SERVICE_CORS_ORIGIN` | CORS origin (default `*`) |

**Endpoints:** `GET /health` — `GET /?action=getSiteContent` — `POST /v1/chat` or `POST /` with `{ "messages": [...] }` (key required except `/health`).

**Next.js:** pass `serviceUrl` + `serviceApiKey` to `CmsProvider` so the widget and `refresh()` hit your host. Public keys in `NEXT_PUBLIC_*` are visible in the browser; for stricter control, proxy chat through your Next.js API and keep the key server-side only.

---

## How the pieces fit together

```mermaid
flowchart LR
  subgraph browser [Browser]
    Widget[CmsWidget / ChatPanel]
    Page[Your pages with hooks]
  end
  subgraph next [Next.js server]
    API[createCmsApiHandler]
    RSC[getSiteContent / metadata]
  end
  subgraph ai [AI layer]
    Agent[runAgent]
    Claude[Claude + tools]
  end
  DB[(SQLite or Turso)]
  Widget -->|POST messages| API
  API --> Agent
  Agent --> Claude
  Agent <-->|read/write| DB
  Page -->|hooks| RSC
  RSC --> DB
```

- **Import paths**: `aicms` (client-safe hooks, provider, `defineConfig`), `aicms/server` (loaders, metadata, JSON-LD, API factories), `aicms/widget` (floating UI).

---

## The agent loop (for learning)

Classic **tool use** with Anthropic:

1. You send **messages** (user/assistant text).
2. Claude returns either **text only** (you’re done) or **tool_use** blocks.
3. For each tool, your code runs the matching logic (`executeTool`) and builds **tool_result** payloads.
4. You append an **assistant** message (with the tool_use blocks) and a **user** message (with the tool results), then call the API again.
5. Repeat until there are no tool calls or you hit a **max iteration** guard (here: 10).

The **system prompt** (`buildSystemPrompt`) injects current content keys and menu summaries so the model knows what exists before editing. **CMS_TOOLS** (`src/ai/tools.ts`) is the JSON schema Claude uses to decide which tool to call and with which arguments.

**Note:** Testimonials are stored and exposed on the site via `getSiteContent` / hooks, but the current tool set in `executeTool` focuses on **content keys** and **menu** operations. Extending tools for testimonials would follow the same pattern as menu items.

---

## Configuration and environment

| Variable | Purpose |
|----------|---------|
| `ANTHROPIC_API_KEY` | Required for the AI agent; without it the API returns a friendly error. |
| `AICMS_AI_MODEL` | Optional override for the Claude model (default is set in `runAgent`). |
| `TURSO_DATABASE_URL` / `TURSO_AUTH_TOKEN` | If set, storage uses Turso; otherwise SQLite. |
| `AICMS_DB_PATH` | SQLite file path (default `./aicms.db`). |

Auth for the API is handled by `createCmsAuthHandler` / `isAuthenticated` (secret-based or custom, depending on how you configure the host app).

---

## Scripts

| Command | Description |
|---------|-------------|
| `npm run build` | Bundle with `tsup` to `dist/` (CJS + ESM). |
| `npm run dev` | Watch mode for development. |
| `npm run typecheck` | `tsc --noEmit`. |

---

## Mental model

- **Library or hosted API** — embed the package in Next.js, **or** run `aicms serve` and sell access by API key + per-tenant DBs.
- **AI does not run arbitrary SQL** — it only invokes **named tools** with validated-shaped inputs; your server maps those to storage calls.
- **Separation of entries** — `src/index.ts` avoids server-only code so client bundles stay clean; heavy and AI routes live under `aicms/server`.

If you want to go deeper, read in this order: `src/ai/agent.ts` (loop + tool dispatch), `src/ai/tools.ts` (what the model may call), `src/storage/adapter.ts` (schema and interface), then `src/content/server.ts` and `src/content/hooks.ts` (how pages consume data).

---

## License

MIT
